API Endpoint - /flights

Parameters
	source - String (Departure city)
	destination - String (Arrival city)
	departureDate - long (date in epoc)
	sortBy - String ('departureTime')
	direction - String (ASC/DSC)
	pageSize - int
	pageNum - int 
	
Sample
	Request
	localhost:8080/flights?source=Singapore&destination=Istanbul
	
	Response 
	{"content":[{"source":"Singapore","destination":"Istanbul","departureTime":1563588000,"arrivalTime":1563678000,"duration":90000,"type":"BUISNESS"},{"source":"Singapore","destination":"Istanbul","departureTime":1558907735,"arrivalTime":1558907735,"duration":0,"type":"BUISNESS"}],
	"pageable":{"sort":{"sorted":true,"unsorted":false,"empty":false},"offset":10,"pageNumber":1,"pageSize":10,"paged":true,"unpaged":false},"last":true,"totalElements":12,"totalPages":2,"size":10,"number":1,"numberOfElements":2,"sort":{"sorted":true,"unsorted":false,"empty":false},"first":false,"empty":false}