package com.tokiGames.app.dao.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tokiGames.app.dao.FlightDAO;
import com.tokiGames.app.model.BuisnessFlightDTO;
import com.tokiGames.app.model.CheapFlightDTO;
import com.tokiGames.app.model.Flight;
import com.tokiGames.app.model.FlightType;

@Repository
public class FlightDAOImpl implements FlightDAO{

	
	private List<CheapFlightDTO> getCheapFlights(){
		String uri = "https://tokigames-challenge.herokuapp.com/api/flights/cheap";
    	JSONObject obj = new JSONObject();
    	RestTemplate restTemplate = new RestTemplate();
    	List<CheapFlightDTO> flightList = new ArrayList<>();
    	String result = restTemplate.getForObject(uri, String.class);
    	try {
			obj = new JSONObject(result);
			ObjectMapper mapper = new ObjectMapper();
			String str = obj.getJSONArray("data").toString();
			flightList = mapper.readValue(str, new TypeReference<List<CheapFlightDTO>>(){});
			System.out.println("ok");
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return flightList;
	}
	
	private List<BuisnessFlightDTO> getBuisnessFlights(){
		String uri = "https://tokigames-challenge.herokuapp.com/api/flights/business";
    	JSONObject obj = new JSONObject();
    	RestTemplate restTemplate = new RestTemplate();
    	List<BuisnessFlightDTO> flightList = new ArrayList<>();
    	String result = restTemplate.getForObject(uri, String.class);
    	try {
			obj = new JSONObject(result);
			ObjectMapper mapper = new ObjectMapper();
			String str = obj.getJSONArray("data").toString();
			flightList = mapper.readValue(str, new TypeReference<List<BuisnessFlightDTO>>(){});
			System.out.println("ok");
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return flightList;
	}
	
	public Page<Flight> getFlights(String source,String destination,Long departureTime, Pageable pageable){
		List<CheapFlightDTO> cheapFlights = getCheapFlights();
		List<BuisnessFlightDTO> buisnessFlights = getBuisnessFlights();
		List<Flight> flightList = new ArrayList<>();
		Long time = null;
		if(departureTime!=null){
			Calendar departCal = Calendar.getInstance();
			departCal.setTimeInMillis(departureTime);
			departCal.set(Calendar.HOUR_OF_DAY, 0);
			departCal.set(Calendar.MINUTE, 0);
			departCal.set(Calendar.SECOND, 0);
			departCal.set(Calendar.MILLISECOND, 0);
			time = departCal.getTimeInMillis();
		}
		for(CheapFlightDTO obj : cheapFlights){
			if(source!=null && !obj.getSource().equalsIgnoreCase(source))
				continue;
			if(destination!=null && !obj.getDestination().equalsIgnoreCase(destination))
				continue;
			if(time!=null && obj.getDepartureTime()<time)
				continue;
			Flight flight = new Flight();
			flight.setSource(obj.getSource());
			flight.setDestination(obj.getDestination());
			flight.setDepartureTime(obj.getDepartureTime());
			flight.setArrivalTime(obj.getArrivalTime());
			flight.setDuration(obj.getArrivalTime() - obj.getDepartureTime());
			flight.setType(FlightType.CHEAP);
			flightList.add(flight);
		}
		
		for(BuisnessFlightDTO obj : buisnessFlights){
			if(source!=null && !obj.getSource().equalsIgnoreCase(source))
				continue;
			if(destination!=null && !obj.getDestination().equalsIgnoreCase(destination))
				continue;
			if(time!=null && obj.getDepartureTime()<time)
				continue;
			Flight flight = new Flight();
			flight.setSource(obj.getSource());
			flight.setDestination(obj.getDestination());
			flight.setDepartureTime(obj.getDepartureTime());
			flight.setArrivalTime(obj.getArrivalTime());
			flight.setDuration(obj.getArrivalTime() - obj.getDepartureTime());
			flight.setType(FlightType.BUISNESS);
			flightList.add(flight);
		}
		Page<Flight> page = new PageImpl<>(flightList, pageable,flightList.size());
		return page;
	}
}
