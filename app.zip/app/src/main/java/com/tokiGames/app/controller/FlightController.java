package com.tokiGames.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tokiGames.app.exception.InvalidRequestParametersException;
import com.tokiGames.app.exception.RecordNotFoundException;
import com.tokiGames.app.model.Flight;
import com.tokiGames.app.service.FlightService;


@RestController
public class FlightController {
    @Autowired
    private FlightService flightService;
    
    @RequestMapping(value = "/flights", method = RequestMethod.GET)
    public ResponseEntity<Object> getFlights(
    		@RequestParam(required=false) String source, 
    		@RequestParam(required=false) String destination, 
    		@RequestParam(required=false) Long departureDate,
    		@RequestParam(defaultValue = "1") Integer pageNum, 
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "departureTime") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction){
    	
    	Sort.Direction dir = Sort.Direction.fromString(direction);
    	if(dir==null || (sortBy!=null & !sortBy.equalsIgnoreCase("departureTime")))
    		throw new InvalidRequestParametersException();
    	
    	Pageable pageable = PageRequest.of(pageNum, pageSize,dir,sortBy);
    	Page<Flight> flights = flightService.getFlights(source, destination, departureDate, pageable);
        if(flights.isEmpty())
        	throw new RecordNotFoundException();
    	return new ResponseEntity<Object>(flights, HttpStatus.OK);
    }
}

