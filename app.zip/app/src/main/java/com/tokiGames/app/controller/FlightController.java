package com.tokiGames.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tokiGames.app.model.Flight;
import com.tokiGames.app.service.FlightService;

@RestController
public class FlightController {
    @Autowired
    private FlightService flightService;
    
    @RequestMapping(value = "/flights", method = RequestMethod.GET)
    public ResponseEntity<Object> getFlights(
    		@RequestParam(required=false) String source, 
    		@RequestParam(required=false) String destination, 
    		@RequestParam(required=false) Long departureDate,
    		@RequestParam(defaultValue = "1") Integer pageNo, 
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "departureTime") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction) {
    	Sort.Direction dir = Sort.Direction.fromString(direction);
    	Pageable pageable = PageRequest.of(pageNo, pageSize,dir,sortBy);
    	Page<Flight> flights = flightService.getFlights(source, destination, departureDate, pageable);
        //Mono<Employee> e = employeeService.findById(id);
        //HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
        return new ResponseEntity<Object>(flights, HttpStatus.OK);
    }
}

