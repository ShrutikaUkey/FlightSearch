package com.tokiGames.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.tokiGames.app.dao.FlightDAO;
import com.tokiGames.app.model.Flight;
import com.tokiGames.app.service.FlightService;
 
@Service
public class FlightServiceImpl implements FlightService {
    @Autowired
    FlightDAO flightDAO;
	
    public Page<Flight> getFlights(String source,String destination,Long time,Pageable pageable){
    	return flightDAO.getFlights(source, destination, time,pageable);
    }
}
