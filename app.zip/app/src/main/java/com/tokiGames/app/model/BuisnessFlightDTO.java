package com.tokiGames.app.model;

public class BuisnessFlightDTO extends FlightDTO{
	String departure;
	String arrival;
	
	public void setDeparture(String departure) {
		setSource(departure);
	}
	
	public void setArrival(String arrival) {
		setDestination(arrival);
	}
}
