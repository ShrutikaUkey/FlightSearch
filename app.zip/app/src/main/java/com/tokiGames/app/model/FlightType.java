package com.tokiGames.app.model;

public enum FlightType {
	CHEAP("cheap"),
	BUISNESS("buisness");
	
	String label;
	
	FlightType(String label){
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
