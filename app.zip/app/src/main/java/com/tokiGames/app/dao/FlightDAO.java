package com.tokiGames.app.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tokiGames.app.model.Flight;

public interface FlightDAO {
	public Page<Flight> getFlights(String source,String destination,Long time, Pageable pageable);
	
}
