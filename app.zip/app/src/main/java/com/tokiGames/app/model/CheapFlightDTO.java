package com.tokiGames.app.model;

public class CheapFlightDTO extends FlightDTO{
	String route;
	long departure;
	long arrival;
	
	public void setRoute(String route) {
		String[] routeArr = route.split("-");
		setSource(routeArr[0]);
		setDestination(routeArr[1]);
	}
	
	public void setDeparture(long departure) {
		setDepartureTime(departure);
	}
	
	public void setArrival(long arrival) {
		setArrivalTime(arrival);
	}
}
