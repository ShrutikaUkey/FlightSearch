package com.tokiGames.app.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST ,reason ="Invalid request parameters")
public class InvalidRequestParametersException extends RuntimeException 
{
	private static final long serialVersionUID = 1L;
}
